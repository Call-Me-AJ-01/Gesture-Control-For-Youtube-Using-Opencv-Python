import cv2
import os
import numpy as np
from PIL import Image
import math,operator
from functools import reduce
import webbrowser as web
from pyautogui import press
web.open("https://www.youtube.com/watch?v=iL6uOp8nIhs")
cap=cv2.VideoCapture(0)#the '0' inside the bracket decribes the cam no for default cam on system the no is '0'
i,k,c=1,0,0
d={}
o="/m"
permanent_path="E:/New Mini Project/Gesture Control/Permanent Right Hand Sign"
permanent_file_name=[]
permanent_file_path=[]
for a in os.listdir(permanent_path):
    permanent_file_name.append(a)
while True:
    ret,frame=cap.read()#the 1st argument ('_') returns true or False based on the window(dispaly) properly created or not and 2nd argument ('frame') reads the picture that is seen on the image
    cv2.rectangle(frame, (1,420), (200, 200), (0, 0, 255), 2)#(frame,(SOP x, SOP y),(EOP x,EOP y),(BLUE,GREEN,RED),thickness) NOTE:-SOP->starting point of 
    #                    --------------------------------------
    while k>100:
        #frame=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)#converting to gray scale
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower = np.array([110, 50, 50], dtype = "uint8") 
        upper = np.array([130,255, 255], dtype = "uint8")
        mask = cv2.inRange(hsv, lower, upper)
        cv2.imwrite("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg",mask[200:420,1:204])#gray[y:y+h,x:x+w]
        #print("picture aj"+str(i)+" taken")
        #i+=1
        h1 = Image.open("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg").histogram()
        img=cv2.imread("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg")
        cv2.imshow('AJ',img)
        for a in permanent_file_name:
            permanent_image=permanent_path+o[0]+a
            h2=Image.open(permanent_image).histogram()
            rms = math.sqrt(reduce(operator.add,map(lambda a,b: (a-b)**2, h1, h2))/len(h1))
            d[rms]=a
        if min(d)>40 and min(d)<42:
            print("No Input")
            print()
        else:
            no=d.get(min(d))
            n=no.split(".")
            #print(n[0][0])
            if n[0][0]=='a':
                press('right')
                press('right')
            elif n[0][0]=='b':
                press('left')
                press('left')
            elif n[0][0]=='c':
                press('m')
            elif n[0][0]=='d':
                press('f')
            elif n[0][0]=='e':
                press('k')
            else:
                pass
        d={}
        os.remove("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg")
        k=-1
    k+=1
    cv2.imshow("Call_Me_AJ",frame)
    if cv2.waitKey(1)==27:
        break
cap.release()
cv2.destroyAllWindows()
